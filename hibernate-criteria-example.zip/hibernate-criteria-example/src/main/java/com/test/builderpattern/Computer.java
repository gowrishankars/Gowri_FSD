package com.test.builderpattern;

public class Computer {
	// required
	private String HDD;
	private String RAM;
	@Override
	public String toString() {
		return "Computer [HDD=" + HDD + ", RAM=" + RAM + ", isGraphicsEnabled=" + isGraphicsEnabled
				+ ", isBluetoothEnabled=" + isBluetoothEnabled + "]";
	}

	

	// optinal
	private boolean isGraphicsEnabled;
	private boolean isBluetoothEnabled;

	public String getHDD() {
		return HDD;
	}

	public void setHDD(String hDD) {
		HDD = hDD;
	}

	public String getRAM() {
		return RAM;
	}

	public void setRAM(String rAM) {
		RAM = rAM;
	}

	public boolean isGraphicsEnabled() {
		return isGraphicsEnabled;
	}

	public void setGraphicsEnabled(boolean isGraphicsEnabled) {
		this.isGraphicsEnabled = isGraphicsEnabled;
	}

	public boolean isBluetoothEnabled() {
		return isBluetoothEnabled;
	}

	public void setBluetoothEnabled(boolean isBluetoothEnabled) {
		this.isBluetoothEnabled = isBluetoothEnabled;
	}
	
	public static class ComputerBuilder {
		
		private String HDD;
		private String RAM;
		
		// optinal
		private boolean isGraphicsEnabled;
		private boolean isBluetoothEnabled;

		public ComputerBuilder setHDD(String hDD) {
			this.HDD = hDD;
			return this;
		}

		public ComputerBuilder setRAM(String rAM) {
			this.RAM = rAM;
			return this;
		}
		public ComputerBuilder setGraphicsEnabled(boolean isGraphicsEnabled) {
			this.isGraphicsEnabled = isGraphicsEnabled;
			return this;
		}
		
		public ComputerBuilder setBluetoothEnabled(boolean isBluetoothEnabled) {
			this.isBluetoothEnabled = isBluetoothEnabled;
			return this;
		}
		public ComputerBuilder(String hdd, String ram)
		{
			this.HDD=hdd;
			this.RAM=ram;
		}
		
		public Computer build() {
			return new Computer(this) ;
		}
		

		
	}
	
	private Computer(ComputerBuilder builder)
	{
		this.HDD = builder.HDD;
		this.RAM= builder.RAM;
		this.isBluetoothEnabled = builder.isBluetoothEnabled;
		this.isGraphicsEnabled= builder.isGraphicsEnabled;
	}

}
