package com.test.builderpattern;

public class Main {
	
	public static void main(String[] args) {
		
		Computer c = new Computer.ComputerBuilder("1TB", "8GB")
				.setBluetoothEnabled(true).build();
		
		System.out.println(c);
		
		
	}

}
