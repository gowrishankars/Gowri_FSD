package com.test.builderpattern;

public interface Shape {

	void draw();
	
}
