package com.test.builderpattern;

public class ShapeFactory {
	
	public Shape getShape(String type)
	{
		if(type==null)
		{
			return null;
		}
	else if("circle".equalsIgnoreCase(type))
		{
			return new Circle();
		}
		else if("rectangle".equalsIgnoreCase(type))
		{
			return new Rectangle();
		}
		else
		{
			return null;
		}
	}

}
