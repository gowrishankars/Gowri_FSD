package com.test.builderpattern;

public class FactoryTest {
	
	public static void main(String[] args) {
		Shape shape  = null;
		ShapeFactory factory = new ShapeFactory();
		shape = factory.getShape("rectangle");
		shape.draw();
		
	}

	
}
