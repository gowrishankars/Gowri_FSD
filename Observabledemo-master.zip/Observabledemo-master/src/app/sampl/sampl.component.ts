import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';

@Component({
  selector: 'app-sampl',
  templateUrl: './sampl.component.html',
  styleUrls: ['./sampl.component.css']
})
export class SamplComponent implements OnInit {

  empl : Employee = new Employee();
  constructor() { }

  ngOnInit() {
  }

}
