import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SamplComponent } from './sampl.component';

describe('SamplComponent', () => {
  let component: SamplComponent;
  let fixture: ComponentFixture<SamplComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SamplComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SamplComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
