export class Employee {

    empId : number ;
    empName : string;

    constructor(values : Object ={}) {
        Object.assign(this,values);
    }
}
